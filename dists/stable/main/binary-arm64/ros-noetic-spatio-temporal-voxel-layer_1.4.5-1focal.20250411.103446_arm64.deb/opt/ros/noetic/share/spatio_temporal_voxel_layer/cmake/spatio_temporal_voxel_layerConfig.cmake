# generated from catkin/cmake/template/pkgConfig.cmake.in

# append elements to a list and remove existing duplicates from the list
# copied from catkin/cmake/list_append_deduplicate.cmake to keep pkgConfig
# self contained
macro(_list_append_deduplicate listname)
  if(NOT "${ARGN}" STREQUAL "")
    if(${listname})
      list(REMOVE_ITEM ${listname} ${ARGN})
    endif()
    list(APPEND ${listname} ${ARGN})
  endif()
endmacro()

# append elements to a list if they are not already in the list
# copied from catkin/cmake/list_append_unique.cmake to keep pkgConfig
# self contained
macro(_list_append_unique listname)
  foreach(_item ${ARGN})
    list(FIND ${listname} ${_item} _index)
    if(_index EQUAL -1)
      list(APPEND ${listname} ${_item})
    endif()
  endforeach()
endmacro()

# pack a list of libraries with optional build configuration keywords
# copied from catkin/cmake/catkin_libraries.cmake to keep pkgConfig
# self contained
macro(_pack_libraries_with_build_configuration VAR)
  set(${VAR} "")
  set(_argn ${ARGN})
  list(LENGTH _argn _count)
  set(_index 0)
  while(${_index} LESS ${_count})
    list(GET _argn ${_index} lib)
    if("${lib}" MATCHES "^(debug|optimized|general)$")
      math(EXPR _index "${_index} + 1")
      if(${_index} EQUAL ${_count})
        message(FATAL_ERROR "_pack_libraries_with_build_configuration() the list of libraries '${ARGN}' ends with '${lib}' which is a build configuration keyword and must be followed by a library")
      endif()
      list(GET _argn ${_index} library)
      list(APPEND ${VAR} "${lib}${CATKIN_BUILD_CONFIGURATION_KEYWORD_SEPARATOR}${library}")
    else()
      list(APPEND ${VAR} "${lib}")
    endif()
    math(EXPR _index "${_index} + 1")
  endwhile()
endmacro()

# unpack a list of libraries with optional build configuration keyword prefixes
# copied from catkin/cmake/catkin_libraries.cmake to keep pkgConfig
# self contained
macro(_unpack_libraries_with_build_configuration VAR)
  set(${VAR} "")
  foreach(lib ${ARGN})
    string(REGEX REPLACE "^(debug|optimized|general)${CATKIN_BUILD_CONFIGURATION_KEYWORD_SEPARATOR}(.+)$" "\\1;\\2" lib "${lib}")
    list(APPEND ${VAR} "${lib}")
  endforeach()
endmacro()


if(spatio_temporal_voxel_layer_CONFIG_INCLUDED)
  return()
endif()
set(spatio_temporal_voxel_layer_CONFIG_INCLUDED TRUE)

# set variables for source/devel/install prefixes
if("FALSE" STREQUAL "TRUE")
  set(spatio_temporal_voxel_layer_SOURCE_PREFIX /tmp/binarydeb/ros-noetic-spatio-temporal-voxel-layer-1.4.5)
  set(spatio_temporal_voxel_layer_DEVEL_PREFIX /tmp/binarydeb/ros-noetic-spatio-temporal-voxel-layer-1.4.5/obj-aarch64-linux-gnu/devel)
  set(spatio_temporal_voxel_layer_INSTALL_PREFIX "")
  set(spatio_temporal_voxel_layer_PREFIX ${spatio_temporal_voxel_layer_DEVEL_PREFIX})
else()
  set(spatio_temporal_voxel_layer_SOURCE_PREFIX "")
  set(spatio_temporal_voxel_layer_DEVEL_PREFIX "")
  set(spatio_temporal_voxel_layer_INSTALL_PREFIX /opt/ros/noetic)
  set(spatio_temporal_voxel_layer_PREFIX ${spatio_temporal_voxel_layer_INSTALL_PREFIX})
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "WARNING: package 'spatio_temporal_voxel_layer' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  message("${_msg}")
endif()

# flag project as catkin-based to distinguish if a find_package()-ed project is a catkin project
set(spatio_temporal_voxel_layer_FOUND_CATKIN_PROJECT TRUE)

if(NOT "include;/usr/include;/usr/include/eigen3;/usr/include/pcl-1.10;/usr/include/vtk-7.1;/usr/include/freetype2;/usr/include/aarch64-linux-gnu " STREQUAL " ")
  set(spatio_temporal_voxel_layer_INCLUDE_DIRS "")
  set(_include_dirs "include;/usr/include;/usr/include/eigen3;/usr/include/pcl-1.10;/usr/include/vtk-7.1;/usr/include/freetype2;/usr/include/aarch64-linux-gnu")
  if(NOT " " STREQUAL " ")
    set(_report "Check the issue tracker '' and consider creating a ticket if the problem has not been reported yet.")
  elseif(NOT " " STREQUAL " ")
    set(_report "Check the website '' for information and consider reporting the problem.")
  else()
    set(_report "Report the problem to the maintainer 'Steve Macenski <stevenmacenski@gmail.com>' and request to fix the problem.")
  endif()
  foreach(idir ${_include_dirs})
    if(IS_ABSOLUTE ${idir} AND IS_DIRECTORY ${idir})
      set(include ${idir})
    elseif("${idir} " STREQUAL "include ")
      get_filename_component(include "${spatio_temporal_voxel_layer_DIR}/../../../include" ABSOLUTE)
      if(NOT IS_DIRECTORY ${include})
        message(FATAL_ERROR "Project 'spatio_temporal_voxel_layer' specifies '${idir}' as an include dir, which is not found.  It does not exist in '${include}'.  ${_report}")
      endif()
    else()
      message(FATAL_ERROR "Project 'spatio_temporal_voxel_layer' specifies '${idir}' as an include dir, which is not found.  It does neither exist as an absolute directory nor in '\${prefix}/${idir}'.  ${_report}")
    endif()
    _list_append_unique(spatio_temporal_voxel_layer_INCLUDE_DIRS ${include})
  endforeach()
endif()

set(libraries "spatio_temporal_voxel_layer;optimized;/usr/lib/aarch64-linux-gnu/libtbb.so;debug;/usr/lib/aarch64-linux-gnu/libtbb.so;rt;/usr/lib/aarch64-linux-gnu/libopenvdb.so;/usr/lib/aarch64-linux-gnu/libpcl_common.so;/usr/lib/aarch64-linux-gnu/libpcl_kdtree.so;/usr/lib/aarch64-linux-gnu/libpcl_octree.so;/usr/lib/aarch64-linux-gnu/libpcl_search.so;/usr/lib/aarch64-linux-gnu/libpcl_sample_consensus.so;/usr/lib/aarch64-linux-gnu/libpcl_filters.so;/usr/lib/aarch64-linux-gnu/libpcl_io.so;/usr/lib/aarch64-linux-gnu/libpcl_features.so;/usr/lib/aarch64-linux-gnu/libpcl_ml.so;/usr/lib/aarch64-linux-gnu/libpcl_segmentation.so;/usr/lib/aarch64-linux-gnu/libpcl_visualization.so;/usr/lib/aarch64-linux-gnu/libpcl_surface.so;/usr/lib/aarch64-linux-gnu/libpcl_registration.so;/usr/lib/aarch64-linux-gnu/libpcl_keypoints.so;/usr/lib/aarch64-linux-gnu/libpcl_tracking.so;/usr/lib/aarch64-linux-gnu/libpcl_recognition.so;/usr/lib/aarch64-linux-gnu/libpcl_stereo.so;/usr/lib/aarch64-linux-gnu/libpcl_apps.so;/usr/lib/aarch64-linux-gnu/libpcl_outofcore.so;/usr/lib/aarch64-linux-gnu/libpcl_people.so;/usr/lib/aarch64-linux-gnu/libboost_filesystem.so;/usr/lib/aarch64-linux-gnu/libboost_iostreams.so;/usr/lib/aarch64-linux-gnu/libboost_regex.so;optimized;/usr/lib/aarch64-linux-gnu/libqhull.so;debug;/usr/lib/aarch64-linux-gnu/libqhull.so;/usr/lib/aarch64-linux-gnu/libvtkChartsCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonColor-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtksys-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonDataModel-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonMath-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonMisc-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonSystem-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonTransforms-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonExecutionModel-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersGeneral-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkCommonComputationalGeometry-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkInfovisCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersExtraction-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersStatistics-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingFourier-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkalglib-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingContext2D-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersGeometry-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersSources-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingFreeType-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libfreetype.so;/usr/lib/aarch64-linux-gnu/libz.so;/usr/lib/aarch64-linux-gnu/libvtkFiltersModeling-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingSources-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkInteractionStyle-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkInteractionWidgets-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkFiltersHybrid-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingColor-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingGeneral-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkImagingHybrid-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOImage-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkDICOMParser-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkmetaio-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libjpeg.so;/usr/lib/aarch64-linux-gnu/libpng.so;/usr/lib/aarch64-linux-gnu/libtiff.so;/usr/lib/aarch64-linux-gnu/libvtkRenderingAnnotation-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingVolume-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOXML-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOXMLParser-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libexpat.so;/usr/lib/aarch64-linux-gnu/libvtkIOGeometry-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOLegacy-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkIOPLY-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingLOD-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkViewsContext2D-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkViewsCore-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingContextOpenGL2-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libvtkRenderingOpenGL2-7.1.so.7.1p.1;/usr/lib/aarch64-linux-gnu/libflann_cpp.so;/usr/lib/aarch64-linux-gnu/libboost_system.so;/usr/lib/aarch64-linux-gnu/libboost_thread.so;-lpthread;/usr/lib/aarch64-linux-gnu/libboost_chrono.so;/usr/lib/aarch64-linux-gnu/libboost_date_time.so;/usr/lib/aarch64-linux-gnu/libboost_atomic.so")
foreach(library ${libraries})
  # keep build configuration keywords, target names and absolute libraries as-is
  if("${library}" MATCHES "^(debug|optimized|general)$")
    list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${library})
  elseif(${library} MATCHES "^-l")
    list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${library})
  elseif(${library} MATCHES "^-")
    # This is a linker flag/option (like -pthread)
    # There's no standard variable for these, so create an interface library to hold it
    if(NOT spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS)
      set(spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS 0)
    endif()
    # Make sure the target name is unique
    set(interface_target_name "catkin::spatio_temporal_voxel_layer::wrapped-linker-option${spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS}")
    while(TARGET "${interface_target_name}")
      math(EXPR spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS "${spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS}+1")
      set(interface_target_name "catkin::spatio_temporal_voxel_layer::wrapped-linker-option${spatio_temporal_voxel_layer_NUM_DUMMY_TARGETS}")
    endwhile()
    add_library("${interface_target_name}" INTERFACE IMPORTED)
    if("${CMAKE_VERSION}" VERSION_LESS "3.13.0")
      set_property(
        TARGET
        "${interface_target_name}"
        APPEND PROPERTY
        INTERFACE_LINK_LIBRARIES "${library}")
    else()
      target_link_options("${interface_target_name}" INTERFACE "${library}")
    endif()
    list(APPEND spatio_temporal_voxel_layer_LIBRARIES "${interface_target_name}")
  elseif(TARGET ${library})
    list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${library})
  elseif(IS_ABSOLUTE ${library})
    list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${library})
  else()
    set(lib_path "")
    set(lib "${library}-NOTFOUND")
    # since the path where the library is found is returned we have to iterate over the paths manually
    foreach(path /opt/ros/noetic/lib;/opt/ros/noetic/lib)
      find_library(lib ${library}
        PATHS ${path}
        NO_DEFAULT_PATH NO_CMAKE_FIND_ROOT_PATH)
      if(lib)
        set(lib_path ${path})
        break()
      endif()
    endforeach()
    if(lib)
      _list_append_unique(spatio_temporal_voxel_layer_LIBRARY_DIRS ${lib_path})
      list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${lib})
    else()
      # as a fall back for non-catkin libraries try to search globally
      find_library(lib ${library})
      if(NOT lib)
        message(FATAL_ERROR "Project '${PROJECT_NAME}' tried to find library '${library}'.  The library is neither a target nor built/installed properly.  Did you compile project 'spatio_temporal_voxel_layer'?  Did you find_package() it before the subdirectory containing its code is included?")
      endif()
      list(APPEND spatio_temporal_voxel_layer_LIBRARIES ${lib})
    endif()
  endif()
endforeach()

set(spatio_temporal_voxel_layer_EXPORTED_TARGETS "spatio_temporal_voxel_layer_gencfg;spatio_temporal_voxel_layer_generate_messages_cpp;spatio_temporal_voxel_layer_generate_messages_eus;spatio_temporal_voxel_layer_generate_messages_lisp;spatio_temporal_voxel_layer_generate_messages_nodejs;spatio_temporal_voxel_layer_generate_messages_py")
# create dummy targets for exported code generation targets to make life of users easier
foreach(t ${spatio_temporal_voxel_layer_EXPORTED_TARGETS})
  if(NOT TARGET ${t})
    add_custom_target(${t})
  endif()
endforeach()

set(depends "geometry_msgs;laser_geometry;message_filters;pcl_ros;pcl_conversions;pluginlib;roscpp;sensor_msgs;std_msgs;costmap_2d;tf2_ros;tf2_geometry_msgs;visualization_msgs;dynamic_reconfigure")
foreach(depend ${depends})
  string(REPLACE " " ";" depend_list ${depend})
  # the package name of the dependency must be kept in a unique variable so that it is not overwritten in recursive calls
  list(GET depend_list 0 spatio_temporal_voxel_layer_dep)
  list(LENGTH depend_list count)
  if(${count} EQUAL 1)
    # simple dependencies must only be find_package()-ed once
    if(NOT ${spatio_temporal_voxel_layer_dep}_FOUND)
      find_package(${spatio_temporal_voxel_layer_dep} REQUIRED NO_MODULE)
    endif()
  else()
    # dependencies with components must be find_package()-ed again
    list(REMOVE_AT depend_list 0)
    find_package(${spatio_temporal_voxel_layer_dep} REQUIRED NO_MODULE ${depend_list})
  endif()
  _list_append_unique(spatio_temporal_voxel_layer_INCLUDE_DIRS ${${spatio_temporal_voxel_layer_dep}_INCLUDE_DIRS})

  # merge build configuration keywords with library names to correctly deduplicate
  _pack_libraries_with_build_configuration(spatio_temporal_voxel_layer_LIBRARIES ${spatio_temporal_voxel_layer_LIBRARIES})
  _pack_libraries_with_build_configuration(_libraries ${${spatio_temporal_voxel_layer_dep}_LIBRARIES})
  _list_append_deduplicate(spatio_temporal_voxel_layer_LIBRARIES ${_libraries})
  # undo build configuration keyword merging after deduplication
  _unpack_libraries_with_build_configuration(spatio_temporal_voxel_layer_LIBRARIES ${spatio_temporal_voxel_layer_LIBRARIES})

  _list_append_unique(spatio_temporal_voxel_layer_LIBRARY_DIRS ${${spatio_temporal_voxel_layer_dep}_LIBRARY_DIRS})
  _list_append_deduplicate(spatio_temporal_voxel_layer_EXPORTED_TARGETS ${${spatio_temporal_voxel_layer_dep}_EXPORTED_TARGETS})
endforeach()

set(pkg_cfg_extras "spatio_temporal_voxel_layer-msg-extras.cmake")
foreach(extra ${pkg_cfg_extras})
  if(NOT IS_ABSOLUTE ${extra})
    set(extra ${spatio_temporal_voxel_layer_DIR}/${extra})
  endif()
  include(${extra})
endforeach()
